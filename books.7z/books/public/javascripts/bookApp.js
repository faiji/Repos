var app = angular.module('bookApp', ['ngRoute','ngResource']).run(function($rootScope){});

app.config(function($routeProvider){
	$routeProvider
		//the timeline display
		.when('/', {
			templateUrl: 'main.html',
			controller: 'mainController'
		})
		//the Add new book display
		.when('/book', {
			templateUrl: 'book.html',
			controller: 'addController',
           
		})
		//the Add new author display
		.when('/author', {
			templateUrl: 'author.html'
		});
});


app.controller('mainController', function($scope, $http) {

$http({ method: 'get', url: 'http://172.27.12.104:3000/book/list' }).success(function (data) {
    console.log('hello');
    $scope.bookmarks = data; // response data 
    console.log($scope.bookmarks);
}).
error(function (data) {
    console.log(data);
});
});


app.controller("addController", function ($scope, $http) {


        $scope.addBook = function () {
           // use $.param jQuery function to serialize data from JSON 
             var data = $.param({
                isbn : $scope.isbn,
                title : $scope.title,
                author : $scope.author
            }); 
        
            var config = {
              
                headers : {
                   // 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                        'Content-Type': 'application/json;charset=utf-8;'
                         }
            }

            $http.post('http://172.27.12.104:3000/book/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.newPost = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
        };

    });





/*
app.controller('addController', function($scope, $http) {


$scope.addBook = function(){     
   // $scope.companies.push({ 'isbn':$scope.isbn, 'title': $scope.title, 'author':$scope.author });
    // Writing it to the server


    //

    var config = {
        headers : {
            'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
        }
    }

    var dataObj = {
                isbn : $scope.isbn,
                title : $scope.title,
                author : $scope.author
        };        
    //var data = 'isbn=' + $scope.isbn + '&title=' + $scope.title + '&author=' + $scope.author;                               
    $http.post('http://172.27.12.104:3000/book/new', dataObj ,config)
    .success(function(data, status, headers, config) {
        $scope.newPost = data;
    })
    .error(function(data, status, headers, config) {
        alert( "failure message: " + JSON.stringify({data: data}));
    });
    // Making the fields empty
    //
    $scope.isbn='';
    $scope.title='';
    $scope.author='';
};


});


*/



/*
app.factory('bookService', function($resource){
    return $resource('http://172.27.12.104:3000/book/new');
});

app.controller('addController', function(bookService, $scope, $rootScope){
    $scope.posts = bookService.query();
 
    $scope.newBook = {isbn: '', title: '', author: '',price: '', availableOn: ''};

    $scope.post = function() {
      $scope.newBook.isbn = $rootScope.isbn;
      $scope.newBook.title = $rootScope.title;
      $scope.newBook.author = $rootScope.price;
      $scope.newBook.availableOn = $rootScope.availableOn;
      
      bookService.save($scope.newBook, function(){
        $scope.posts = bookService.query();
        $scope.newBook = {isbn: '', title: '', author: '',price: '', availableOn: ''};
      });
    };
});


*/


  



