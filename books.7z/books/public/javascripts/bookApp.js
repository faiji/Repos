// Following code contains 4-controller 5-view

var app = angular.module('bookApp',
 ['ngRoute',
 'ngResource']).run(function($rootScope){});

//Actual routing for single page done here
//switch between different view
app.config(function($routeProvider){
	$routeProvider
		//the timeline display
		.when('/', {
			templateUrl: 'main.html',
			controller: 'mainController'
		})
		//the Add new book display
		.when('/book', {
			templateUrl: 'book.html',
			controller: 'addController'   
		})
		//the Add new author display
		.when('/author', {
			templateUrl: 'author.html',
            controller: 'addController'
		})
        //the edit and delete operation for author API's
        .when('/user',{
            templateUrl: 'user.html',
            controller: 'authorEditController'
        })
        //the edit and delete operation for book API's
        .when('/isbn',{
            templateUrl: 'isbn.html',
            controller: 'bookEditController'
        });
});


//This Controller is use 172.27.12.104:3000/book/list API for first page
app.controller('mainController', function($scope, $http) {

    $http({ method: 'get', url: 'http://172.27.12.104:3000/book/list' }).success(function (data) {
        console.log('hello');
        $scope.bookmarks = data; // response data 
        console.log($scope.bookmarks);
    }).
    error(function (data) {
        console.log(data);
    });
});


//This Controller use following API's
// 1. 172.27.12.104:3000/book/byname
// 2. 172.27.12.104:3000/author/update
// 3. 172.27.12.104:3000/author/remove
app.controller('authorEditController',['$scope','$location','$http', function($scope,$location,$http) {
    
    name = $location.search(); 
    var name = $.param(name);

    var config = {
          
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
            }
    }

    $http.post('http://172.27.12.104:3000/author/byname', name, config)
        .success(function (data, status, headers, config) {
            $scope.byname = data;
            console.log(data);
        })
        .error(function (data, status, header, config) {
            $scope.byname = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config;
        });


    $scope.updateAuthor = function (byname) {
        console.log("hi");
        var data = $.param({
            empid: $scope.byname.empid,
            name: $scope.byname.name,
            email: $scope.byname.email,
            website: $scope.byname.website,
            department: $scope.byname.department
            //availableOn: $scope.byisbn.availableOn
        });

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
                 }
        }

        $http.put('http://172.27.12.104:3000/author/update', data, config)
            .success(function (data, status, headers, config) {
                $scope.ResponseAuthor = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseAuthor = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });      
    };


     $scope.deleteAuthor = function (byname) {
        /*console.log(byname);
        var empid1 = {empid:byname.empid};
        var data = $.param(empid1);
            //availableOn: $scope.byisbn.availableOn);

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
                 }
        };*/


        $http({

            method:'DELETE',
            url:'http://172.27.12.104:3000/author/remove',
            data:'empid='+byname+'',
            headers:{'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(function(data){

            console.log(data);
        })
        .error(function(data){       
        });


       /* $http.delete('http://172.27.12.104:3000/author/remove?'+data,config)
            .success(function (data, status, headers, config) {
                $scope.DeleteAuthorResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.DeleteAuthorResponse = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config; 
            }); */      
    };
}]);


//This Controller use following API's
// 1. 172.27.12.104:3000/book/byisbn
// 2. 172.27.12.104:3000/book/update
// 3. 172.27.12.104:3000/book/remove
app.controller('bookEditController', function($scope,$location,$http) {

    isbn = $location.search();
    var isbn = $.param(isbn);
 
    var config = {
          
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
                 }
    }

    $http.post('http://172.27.12.104:3000/book/byisbn',isbn, config)
        .success(function (data, status, headers, config) {
            $scope.byisbn = data;
        })
        .error(function (data, status, header, config) {
            $scope.ResponseDetails = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config;
        });

    $scope.UpdateBook = function (byisbn) {
        console.log("hi");
        var data = $.param({
            isbn: $scope.byisbn.isbn,
            title: $scope.byisbn.title,
            price: $scope.byisbn.price
            //availableOn: $scope.byisbn.availableOn
        });

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
            }
        }

        $http.put('http://172.27.12.104:3000/book/update', data, config)
        .success(function (data, status, headers, config) {
            $scope.ResponseBook = data;
        })
        .error(function (data, status, header, config) {
            $scope.ResponseBook = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config;
        });      
    };

     $scope.deleteBook = function (byisbn) {
        console.log(byisbn);
           /* var byisbn12 = {isbn:byisbn.isbn};
            var data = $.param(byisbn12);
            availableOn: $scope.byisbn.availableOn);

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
            }
        };
*/

        $http({

            method:'DELETE',
            url:'http://172.27.12.104:3000/book/remove',
            data:'isbn='+byisbn+'',
            headers:{'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(function(data){

            console.log(data);
        })
        .error(function(data){
        });


       /* $http.delete('http://172.27.12.104:3000/book/remove?isbn='+byisbn,config)
        .success(function (data, status, headers, config) {
            $scope.DeleteBookResponse = data;
        })
        .error(function (data, status, header, config) {
            $scope.DeleteBookResponse = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config; 
        });  */     
    };
});


//This Controller use following API's
// 1. 172.27.12.104:3000/book/new
// 2. 172.27.12.104:3000/author/new
app.controller("addController", function ($scope, $http) {

    $scope.addBook = function () {
       // use $.param jQuery function to serialize data from JSON 

          $scope.outputs = {};
          $scope.inputs = {
            'skills': ['one','two','three']
          };

        var data = $.param({
            isbn : $scope.isbn,
            title : $scope.title,
            author : $scope.author

        }); 
    
        var config = {
          
            headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                   //'Content-Type': 'application/json;charset=utf-8;'
                 }
        }

        $http.post('http://172.27.12.104:3000/book/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.newPost = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
    };

     $scope.addAuthor = function () {
       // use $.param jQuery function to serialize data from JSON 
        console.log("faiji");
         var data = $.param({
            empid : $scope.empid,
            name : $scope.name,
            email : $scope.email
        }); 
         
        var config = {
          
            headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
                 //   'Content-Type': 'application/json;charset=utf-8;'
            }
        }

        $http.post('http://172.27.12.104:3000/author/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.addAuthorResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.addAuthorResponse = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
    };
});





