// Following code contains 4-controller 5-view

var app = angular.module('bookApp',
 ['ngRoute',
 'ngResource','checklist-model']).run(function($rootScope){});
//Actual routing for single page done here
//switch between different view
app.config(function($routeProvider){
	$routeProvider
		//the timeline display
		.when('/', {
			templateUrl: 'main.html',
			controller: 'mainController'
		})
		//the Add new book display
		.when('/book', {
			templateUrl: 'book.html',
			controller: 'addController'   
		})
		//the Add new author display
		.when('/author', {
			templateUrl: 'author.html',
            controller: 'addController'
		})
        //the edit and delete operation for author API's
        .when('/user',{
            templateUrl: 'user.html',
            controller: 'authorEditController'
        })
        //the edit and delete operation for book API's
        .when('/isbn',{
            templateUrl: 'isbn.html',
            controller: 'bookEditController'
        });
});


//This Controller is use 172.27.12.104:3000/book/list API for first page
app.controller('mainController', function($scope, $http) {

    $http({ method: 'get', 
            url: 'http://172.27.12.104:3000/book/list' }).
            success(function (data) {
                    console.log('hello');
                    $scope.bookmarks = data; // response data 
                    console.log($scope.bookmarks);
            }).
            error(function (data) {
                console.log(data);
            });
    });


//This Controller use following API's
// 1. 172.27.12.104:3000/book/byname
// 2. 172.27.12.104:3000/author/update
// 3. 172.27.12.104:3000/author/remove
app.controller('authorEditController',
                ['$scope',
                '$location',
                '$http', 
    function($scope,$location,$http) {

        name = $location.search(); 
        var name = $.param(name);
        console.log(name);

        var config = {
              
            headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                   //'Content-Type': 'application/json;charset=utf-8;'
                }
        }

        $http.post('http://172.27.12.104:3000/author/byname', name, config)
            .success(function (data, status, headers, config) {
                $scope.byname = data;
                console.log(data);
            })
            .error(function (data, status, header, config) {
                $scope.byname = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });


    $scope.updateAuthor = function (byname) {
        $scope.isDisabled = true; //This dissable edit button first
        console.log("hi");
        var data = $.param({
            empid: $scope.byname.empid,
            name: $scope.byname.name,
            email: $scope.byname.email,
            website: $scope.byname.website,
            department: $scope.byname.department
            //availableOn: $scope.byisbn.availableOn
        });

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
                 }
        }

        $http.put('http://172.27.12.104:3000/author/update', data, config)
            .success(function (data, status, headers, config) {
                $scope.ResponseAuthor = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseAuthor = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });      
    };

    //Change the text of edit buctton on click
    $scope.toggle = true;

    $scope.$watch('toggle', function(){
        $scope.toggleText = $scope.toggle ? 'Edit!' : 'Back';
    })


// Show the Update and delete button on-click
    $scope.buttonText = 'Edit';

    $scope.IsVisible = false;
            $scope.ShowHide = function () {
                //If DIV is visible it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
            }



     $scope.deleteAuthor = function (byname) {
         $scope.isDisabled = true; //dissble edit button first
      
        $http({

            method:'DELETE',
            url:'http://172.27.12.104:3000/author/remove',
            data:'empid='+byname+'',
            headers:{'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(function(data){
             $scope.ResponseAuthor = data;
            console.log(data);
        })
        .error(function(data){       
        });
    
    };
}]);


//This Controller use following API's
// 1. 172.27.12.104:3000/book/byisbn
// 2. 172.27.12.104:3000/book/update
// 3. 172.27.12.104:3000/book/remove
app.controller('bookEditController', function($scope,$location,$http) {

    isbn = $location.search();
    var isbn = $.param(isbn);
 
    var config = {
          
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
                 }
    }

    $http.post('http://172.27.12.104:3000/book/byisbn',isbn, config)
        .success(function (data, status, headers, config) {
            $scope.byisbn = data;
        })
        .error(function (data, status, header, config) {
            $scope.ResponseDetails = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config;
        });

    $scope.UpdateBook = function (byisbn) {
        console.log("hi");
            $scope.isDisabled = true; //This dissable edit button first
            var data = $.param({
            isbn: $scope.byisbn.isbn,
            title: $scope.byisbn.title,
            price: $scope.byisbn.price
            //availableOn: $scope.byisbn.availableOn
        });

        var config = {
      
        headers : {
                'Content-Type': 'application/x-www-form-urlencoded'
               //'Content-Type': 'application/json;charset=utf-8;'
            }
        }

        $http.put('http://172.27.12.104:3000/book/update', data, config)
        .success(function (data, status, headers, config) {
            $scope.ResponseBook = data;
        })
        .error(function (data, status, header, config) {
            $scope.ResponseBook = "Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config;
        });      
    };


//Change the text of edit buctton on click
    $scope.toggle = true;

    $scope.$watch('toggle', function(){
        $scope.toggleText = $scope.toggle ? 'Edit!' : 'Back';
    })


// Show the Update and delete button on-click
    $scope.buttonText = 'Edit';
    $scope.IsVisible = false;
            $scope.ShowHide = function () {
                //If DIV is visible it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
            }


     $scope.deleteBook = function (byisbn) {
         $scope.isDisabled = true; //dissble edit button first
        console.log(byisbn);
 

        $http({

            method:'DELETE',
            url:'http://172.27.12.104:3000/book/remove',
            data:'isbn='+byisbn+'',
            headers:{'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(function(data){
            $scope.ResponseBook = data;
            console.log(data);
        })
        .error(function(data){
        });
   
    };
});


//This Controller use following API's
// 1. 172.27.12.104:3000/book/new
// 2. 172.27.12.104:3000/author/new
app.controller("addController", function ($scope, $http) {
    $scope.mysites = ['Amazon', 'eBay', 'Flipkart'];
    $scope.commSites = [];
    $scope.mysites1 = ['NodeJs', 'JavaScript', 'AngularJs','React'];
    $scope.commSites1 = [];

    $scope.addBook = function () {
       // use $.param jQuery function to serialize data from JSON

        var data = {
            isbn : $scope.isbn,
            title : $scope.title,
            author : $scope.author,
            price : $scope.price,
            availableOn : $scope.commSites
        }; 
    
   
    console.log(data);


        
        var config = {
          
            headers : {
                   // 'Content-Type': 'application/x-www-form-urlencoded'
                   'Content-Type': 'application/json'
                 }
        }

        $http.post('http://172.27.12.104:3000/book/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.newPost = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
    };

     $scope.addAuthor = function () {
 

        var data = {
            empid : $scope.empid,
            name : $scope.name,
            email : $scope.email,
            website: $scope.website,
            department : $scope.department, 
            skills : $scope.commSites1
        }
         
        var config = {
          
            headers : {
                //'Content-Type': 'application/x-www-form-urlencoded'
                 'Content-Type': 'application/json'
            }
        }

        $http.post('http://172.27.12.104:3000/author/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.addAuthorResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.addAuthorResponse = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
    };
});





