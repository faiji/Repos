<html>


<script>

this.x = 9;
var module = {
    x: 81,
    get: function () { return this.x; }
};
 var retrieve = module.get;
 
retrieve.bind(module);
retrieve.bind(window);

</script>

</html>

